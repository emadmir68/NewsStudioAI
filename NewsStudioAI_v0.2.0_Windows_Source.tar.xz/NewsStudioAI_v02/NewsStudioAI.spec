from PyInstaller.utils.hooks import collect_all

datas = [("static", "static"), ("config", "config")]
binaries = []
hiddenimports = []
for package in ("uvicorn", "fastapi", "PIL", "faster_whisper", "ctranslate2", "av", "webview", "clr_loader", "pythonnet"):
    try:
        d, b, h = collect_all(package)
        datas += d
        binaries += b
        hiddenimports += h
    except Exception:
        pass

a = Analysis(
    ["launcher.py"],
    pathex=["."],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=["tkinter", "matplotlib"],
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz, a.scripts, [], exclude_binaries=True, name="NewsStudioAI",
    debug=False, bootloader_ignore_signals=False, strip=False, upx=True,
    console=True, disable_windowed_traceback=False
)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=True, name="NewsStudioAI")
